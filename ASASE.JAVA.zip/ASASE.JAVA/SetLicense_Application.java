public class SetLicense_Application{
    public static void main(String[]args){
	License_Application asase = new License_Application();
	asase.setName();
	asase.setAge();
	if(asase.getAge()>18){
		asase.setAddress();
		asase.setDistrict();
		asase.setReginal();
		asase.setZanzibarID();
		System.out.println(asase.toString());
	}
	else{
		System.out.println("You under the age");
        }
    }
}