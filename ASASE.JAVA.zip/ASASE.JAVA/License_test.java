public class License_test{
    public static void main(String[]args){
	Medical_form asase = new Medical_form();
	asase.setName();
	asase.setAge();
	if(asase.getAge()>18){
		asase.setAddress();
		asase.setDistrict();
		asase.setReginal();
		asase.setZanzibarID();
        
		System.out.println(asase.toString());
        System.out.println(asase.toStringb());
	}
	else{
		System.out.println("You under the age");
        }
    }
}