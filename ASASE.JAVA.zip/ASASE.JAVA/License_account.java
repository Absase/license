import java.util.Scanner;
public class License_account{
    private String Name;
    private String Email;
    private String password;

    public License_account(){

    }public License_account(String name){
        Name =name;
    }
    public License_account(String Name,String Email,String password){
		this.Name=Name;
        this.Email=Email;
        this.password=password;
    }

    public void setName(){
        Scanner input=new Scanner(System.in);
        System.out.println("Enter the username");
        String Name=input.nextLine();
        this.Name=Name;
    }
    public String getNme(){
        return Name;
    }

    public void setEmail(){
        Scanner input=new Scanner(System.in);
        System.out.println("Enter the email address correctly");
        String Email=input.nextLine();
        this.Email=Email;
    }
    public String getEmail(){
        return Email;
    }

    public void setpassword(){
        Scanner input=new Scanner(System.in);
        System.out.println("Enter the strong paswword");
        String password=input.nextLine();
        this.password=password;
    }
    public String getpassword(){
        return password;
    }
    public String toString(){
        return ("MR/MRS : The username is "+Name+" and the email is "+Email+" and the paswword is *********");
    }

    public static void main(String[]args){
        License_account asase=new License_account();
        asase.setName();
        asase.setEmail();
        asase.setpassword();
        System.out.println(asase.toString());
    }
}