import java.util.Scanner;
public class License extends License_account{
	private int Age;
	private String Address;
	private String District;
	private String Reginal;
	private int ZanzibarID;

	public License(){

	}

	public License(String Name,int Age,String Address,String District,String Reginal,int ZanzibarID){
		super (Name);
		this.Age=Age;
		this.Address=Address;
		this.District=District;
		this.Reginal=Reginal;
		this.ZanzibarID=ZanzibarID;
	}

	public void setAge(){
		Scanner asase=new Scanner(System.in);
		System.out.println("Enter the age");
		int Age= asase.nextInt();
		this.Age=Age;
	}
	public int getAge(){
		return Age;
	}

	public void setAddress(){
		Scanner input=new Scanner(System.in);
		System.out.println("Enter the Address");
		String Address = input.nextLine();
		this.Address=Address;
	}
	public String getAddress(){
		return Address;
	}

	public void setDistrict(){
		Scanner input=new Scanner(System.in);
		System.out.println("Enter the District");
		String District = input.nextLine();
		this.District=District;
	}
	public String getDistrict(){
		return District;
	}

	public void setReginal(){
		Scanner input=new Scanner(System.in);
		System.out.println("Enter the Reginal");
		String Reginal = input.nextLine();
		this.Reginal=Reginal;
	}
	public String getReginal(){
		return Reginal;
	}

	public void setZanzibarID(){
		Scanner asase=new Scanner(System.in);
		System.out.println("Enter the ZanzibarID");
		int ZanzibarID= asase.nextInt();
		this.ZanzibarID=ZanzibarID;
	}
	public int getZanzibarID(){
		return ZanzibarID;
	}

	public String toString(){
	return ("The age is "+Age+" the Address is "+Address+" tha Reginal is Reginal"+Reginal+" and the district is "+District);
	}
		

}